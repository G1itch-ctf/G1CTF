文件名为Encrypto

百度or Google一下 发现是个加密软件

下载安装下来 随便加密一个文件 后缀是.crypto 修改使用软件解密

密码在passwd.txt里面 555

又一个没后缀的

十六进制打开查看 开头/rtf 添加后缀使用word打开获得flag



flag{Encrypto_is_too_difficult}

 