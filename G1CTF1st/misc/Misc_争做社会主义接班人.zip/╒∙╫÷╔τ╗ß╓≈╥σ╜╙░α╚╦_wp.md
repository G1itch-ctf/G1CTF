[社会主义编码](http://ctf.ssleye.com/cvencode.html)

base64解码

flag{Oh_You_find_me}