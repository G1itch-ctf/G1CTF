扔进软件tweakpng

![image-20201213170552515](C:\Users\weisu\AppData\Roaming\Typora\typora-user-images\image-20201213170552515.png)

百度crc32 碰撞高度宽度

或者 如果可以看见微缩图 是有flag的

直接修改图片高度

发现四个绿色色块 使用取色板 发现颜色代码只有最后两位不一样

#42F520

#42F521

#42F566

#42F588

flag{20216688}

